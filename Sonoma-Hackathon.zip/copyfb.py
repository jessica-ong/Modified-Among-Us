import pygame
import time
import random
from pygame.locals import *

#initializes pygame
pygame.init()

##name screen and set screen size
screen = pygame.display.set_mode((600,600))

##give pygame tab a caption
pygame.display.set_caption("Shapes!!")

##colors
blue = (7,228,232)
red = (255,0,0)
green = (52,209,31)
yellow = (243,255,10)
##birds coordinates
by = 300
bx = 200
##pole variables
x=200
y=0
x2 = 400
y2 =480
imagevariable = pygame.image.load('fb.png')
imagevariable = pygame.transform.scale(imagevariable, (100,100))
top_p = pygame.image.load('tp.png')
top_p = pygame.transform.scale(top_p, (85,200))
bottom_p = pygame.image.load('bp.png')
bottom_p = pygame.transform.scale(bottom_p, (90,500))

while True:
    
    ##pole moving mmm
    x = x - 5
    x2 = x2 - 5
    ##pole reappearing
    if x == - 80:
        x = 600
        y = random.randint(-100,0)
    if x2 ==-80:
        x2=600
        y2 = random.randint(150,500)
    ##pole detection
    if bx + 10 == x2 and y2 <= by <600:
        break
    if bx +10 == x and 0 <= by <= y+200:
        break
    if (x2 < bx <x2 +80) and (by + 10 == y2):
        break
    if (x < bx <x +80) and (by - 10 == y + 200 ):
        break
    if by - 10 >=600 or by + 10 <= -10:
        break
    ##birdy going down
    by = by + 10
    time.sleep(.1)
    screen.fill(blue)
    ##pygame.draw.rect(screen, color , (x,y,width,length),thickness)
    ##pygame.draw.rect(screen, green, (x,y,80,200),0)
    ##pygame.draw.rect(screen, green, (x2,y2,80,500),0)
    screen.blit(top_p,(x,y))
    screen.blit(bottom_p,(x2,y2))
    ##pygame.draw.circle(screen, color,(x,y), radius,0,thickness)
    ##pygame.draw.circle(screen, red,(bx,by), 10,0)
    screen.blit(imagevariable,(bx-50,by-50))
    ##pygame.draw.circle(screen, red,(bx,by), 10,0)
    ##pygame.draw.polygon(screen, yellow, ((3,4), (235,87),(234,123),(42,324)),pygame.display.update()

    for event in pygame.event.get():
        ##initaite space hey
        if event.type == KEYDOWN:
            if event.key ==K_SPACE:
                by=by-40
        if event.type == QUIT:
            pygame.display.quit()
            exit()
    pygame.display.update()

    
